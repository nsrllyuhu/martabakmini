# Martabak Mini — Android Project

Project Android WebView untuk aplikasi laporan harian dan stok Martabak Mini.

## Build APK langsung dari HP (tanpa Termux)

Project ini sudah dilengkapi GitHub Actions. Build dilakukan di server GitHub, jadi HP tidak perlu memasang Android Studio, Gradle, atau Termux.

### Langkah

1. Buat repository baru di GitHub, misalnya `martabak-mini`.
2. Upload **isi folder project ini** ke repository (bukan file ZIP-nya).
3. Pastikan branch utama bernama `main`.
4. Buka tab **Actions** di repository.
5. Pilih workflow **Build APK Martabak Mini**.
6. Tekan **Run workflow** jika build belum berjalan otomatis.
7. Setelah selesai, buka hasil workflow dan bagian **Artifacts**.
8. Download `martabak-mini-apk` lalu ambil `app-debug.apk`.
9. Install APK di HP Android.

## Konfigurasi build

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- JDK: 17
- compileSdk: 35
- minSdk: 23
- targetSdk: 35

## Database online

Versi ini masih memakai penyimpanan lokal pada prototype. Workflow GitHub sudah siap untuk build APK. Firebase/database online akan ditambahkan pada tahap berikutnya setelah project Firebase dibuat dan konfigurasi Firebase tersedia.

Struktur data yang akan digunakan nantinya mencakup:
- pengguna Owner/Karyawan
- laporan harian
- penjualan per menu/rasa
- pembayaran tunai/QRIS/transfer
- pengeluaran
- stok bahan
- outlet

## Catatan

File `app/src/main/assets/index.html` adalah tampilan aplikasi yang saat ini dibungkus ke dalam Android WebView.
